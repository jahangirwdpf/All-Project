<?php
echo "hello";

if($_POST("name")){
    echo "hello "+ $_POST("name");
}
?>